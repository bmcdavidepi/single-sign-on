﻿using System;

namespace SampleEpiModules
{
    /// <summary>
    /// Just an example class for testing debug points
    /// </summary>
    public class Class1
    {
        public void Hello()
        {
            var z = ProtectedHello();
            PrivateHelloBad();
        }

        protected int ProtectedHello()
        {
            return 4;
        }

        private void PrivateHelloBad()
        {
            int y = 1;
            int x = 0;
            try
            {
                var r = y / x;
            }
            catch (Exception e)
            {
                throw e;
            }

        }
    }
}