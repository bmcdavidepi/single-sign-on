﻿# Dev Package Tools

This example is how to create a distributable build target as a NuGet package. This concept contains an issue that when installed it comes through as a package dependency and it should not, the work around is to add

```
PrivateAssets="All"
```

To the package reference in the project it is installed. See

```xml
<ItemGroup>
	<PackageReference Include="DevPackageTools" Version="0.1.0" PrivateAssets="All" />
</ItemGroup>
```

This tooling requires devs to set an environment variable on where to store local testing packages that can be consumed in production sites. The environment variable is

CustomPackageOutputPath and a sample value could be

```txt
C:\_dev\testpackages
```

When that environment variable exists, modules that include the DevPackageTools package will place test package there and Visual Studio can setup that path as a NuGet Package source as seen in vs-package-source.png.